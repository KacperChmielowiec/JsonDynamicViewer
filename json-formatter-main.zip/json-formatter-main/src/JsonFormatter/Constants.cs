﻿namespace JsonFormatter;

public static class Constants
{
    public const short IndentationWidth = 35;
    public const int MaxInputLength = 40000;
    public const int MaxNodeCount = 2000;
}

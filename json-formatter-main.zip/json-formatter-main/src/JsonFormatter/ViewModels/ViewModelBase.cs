﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace JsonFormatter.ViewModels;

public class ViewModelBase : ObservableObject
{
}